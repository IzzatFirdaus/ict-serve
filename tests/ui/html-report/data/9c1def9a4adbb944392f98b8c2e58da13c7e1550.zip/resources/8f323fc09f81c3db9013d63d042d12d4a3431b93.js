function c(n){if(!n){console.warn("trapFocus: Modal element is required");return}const o=["a[href]","button:not([disabled])","textarea:not([disabled])","input:not([disabled])","select:not([disabled])",'[tabindex]:not([tabindex="-1"])','[contenteditable="true"]'].join(", "),t=n.querySelectorAll(o);if(!t.length){console.warn("trapFocus: No focusable elements found in modal");return}const e=t[0],i=t[t.length-1];e.focus();function r(a){a.key==="Tab"&&(a.shiftKey?document.activeElement===e&&(a.preventDefault(),i.focus()):document.activeElement===i&&(a.preventDefault(),e.focus()))}return n.addEventListener("keydown",r),function(){n.removeEventListener("keydown",r)}}function s(n,o=null){if(!n)return console.warn("enhancedFocusTrap: Modal element is required"),()=>{};const t=c(n);function e(i){i.key==="Escape"&&o&&o()}return document.addEventListener("keydown",e),function(){t&&t(),document.removeEventListener("keydown",e)}}function u(n,o="polite"){let e=document.getElementById("aria-live-region");e||(e=document.createElement("div"),e.id="aria-live-region",e.setAttribute("aria-live",o),e.setAttribute("aria-atomic","true"),e.className="sr-only",e.style.cssText=`
      position: absolute !important;
      width: 1px !important;
      height: 1px !important;
      padding: 0 !important;
      margin: -1px !important;
      overflow: hidden !important;
      clip: rect(0,0,0,0) !important;
      white-space: nowrap !important;
      border: 0 !important;
    `,document.body.appendChild(e)),e.textContent="",setTimeout(()=>{e.textContent=n},100)}typeof window<"u"&&(window.trapFocus=c,window.enhancedFocusTrap=s,window.announceToScreenReader=u);
